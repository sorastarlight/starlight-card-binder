Starlight Card Binder V80.8 UI Integration

Replace/copy these files into the matching locations in your repository's docs folder:

  docs/binder.html
  docs/collection.html
  docs/checklist.html
  docs/css/v80-8-ui.css
  docs/js/app.js
  docs/js/cloud-collection.js
  docs/js/site-dashboard.js

This update:
- Adds Daily Booster and Star Bits sidebar widgets.
- Replaces Reset Checklist with the Star Bits Exchange link.
- Promotes Daily Booster, Star Bits, and Profile in navigation.
- Moves About and Socials to footer links.
- Stores cloud card quantities locally for the existing Binder engine.
- Displays quantity and duplicate badges on cards.
- Adds quantity to the checklist.
- Adds a Collector Level and stats panel to My Collection.
- Activates the existing Star Bits panel and links it to star-bits.html.

No new SQL is required. It uses the RPC functions and tables created in V80.5–V80.7.

Commit suggestion:
Integrate progression and economy into main site UI
