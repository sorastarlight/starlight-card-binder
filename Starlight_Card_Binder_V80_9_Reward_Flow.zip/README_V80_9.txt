Starlight Card Binder V80.9 — Collection Authority Cleanup

Replace the matching files in your repository's docs folder.

Included changes:
- Removes all user-facing Reveal / Hide Card controls.
- Makes owned and unowned states passive and account-driven.
- Keeps Starlight Mode as a spoiler/preview preference only.
- Keeps the existing Binder reveal animation code for reward use.
- Adds a reusable reward-reveal.js module.
- Updates Daily Booster to reveal each awarded card before showing the pack summary.
- Prevents browser backup imports from changing cloud card ownership.
- Updates collection/checklist wording from browser reveals to earned rewards.
- Keeps favorite controls available only for owned cards.

No new SQL is required.

Suggested GitHub commit:
Phase out manual reveals and unify reward animations
